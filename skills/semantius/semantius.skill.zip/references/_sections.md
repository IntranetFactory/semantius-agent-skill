# Reference Sections

Define sections for reference documentation.

## 1. API Syntax (api)
**Impact:** high
**Description:** PostgREST API query syntax and operators

## 2. Schema Metadata (schema)
**Impact:** high  
**Description:** Platform schema metadata tables and fields

## 3. Access Control (rbac)
**Impact:** high
**Description:** Role-based access control and security
